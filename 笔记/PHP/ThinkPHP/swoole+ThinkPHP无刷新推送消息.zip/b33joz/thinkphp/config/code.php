<?php
/**
 * Created by PhpStorm.
 * User: baidu
 * Date: 18/3/23
 * Time: 上午9:05
 */

return [
    'success' => 1,
    'error' => 0,
];