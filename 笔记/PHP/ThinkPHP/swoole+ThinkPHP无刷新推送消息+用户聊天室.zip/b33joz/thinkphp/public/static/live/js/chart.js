 
//监听swoole是否有消息推送 如果有就用 websocket.onmessage 给前端推送消息
    var Url = "ws://192.168.0.106:8811";

    var websocket = new WebSocket(Url);

    //实例对象的onopen属性
    websocket.onopen = function(evt) {
      console.log("conected-swoole-success");
    }

    // 实例化 onmessage
    websocket.onmessage = function(evt) {
      //
      push(evt.data);
      console.log("ws-server-return-data:" + evt.data);
    }

    //onclose监听swoole窗口关闭
    websocket.onclose = function(evt) {
      console.log("close");
    }

    //onerror
    websocket.onerror = function(evt, e) {
      console.log("error:" + evt.data);
    }

   //组装推送消息模板
   function push(data){
	data=JSON.parse(data);
	html='<div class="comment">';
	html+='<span>'+data.user+'</span>';
	html+='<span>'+data.content+'</span>';
	html+='</div>';
	$('#comments').append(html);
   }
