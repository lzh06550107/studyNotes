CREATE  TABLE `live_team`(
  `id` tinyint(11) unsigned NOT NULL auto_increment,
  `name` VARCHAR(20) NOT NULL DEFAULT '',
  `sex` VARCHAR(20) NOT NULL DEFAULT '',
  `age` tinyint(11) unsigned NOT NULL DEFAULT 0,
  `xueli` char(10)  NULL DEFAULT 0,
  PRIMARY KEY (`id`)
)ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT charset=utf8;




insert into live_team(name,sex,age,xueli)  values('新一','男','25','高中');