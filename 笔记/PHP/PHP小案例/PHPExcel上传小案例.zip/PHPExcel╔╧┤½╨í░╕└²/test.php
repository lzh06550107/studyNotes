<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<meta charset="utf-8">
<body>
<form enctype="multipart/form-data" action="./index.php" method="post">
    <table>
        <tr><td align="center" colspan="2"><font style="font-size: 40px; font-family: 华文彩云;" >上传表格</font></td></tr>
        <tr><td>请先<a href="./sample/sample01.xls">下载excel例子模板</a>编辑后上传文件</td></tr>
　　　　　<tr>
        <td>请选择你要上传的文件</td>
        <td><input type="file" name="myfile"></td>
        </tr>
        <tr><td><input type="submit" value="上传文件" /></td></tr>
    </table>
</form>
</body>
</html>